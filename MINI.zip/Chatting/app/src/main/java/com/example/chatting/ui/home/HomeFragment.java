package com.example.chatting.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.chatting.databinding.FragmentHomeBinding;
import com.example.chatting.R;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        // Set up button click listeners
        binding.btnBuy.setOnClickListener(v -> viewModel.setBuyClicked());
        binding.btnSell.setOnClickListener(v -> viewModel.setSellClicked());

        // Observe buyClicked LiveData
        viewModel.getBuyClicked().observe(getViewLifecycleOwner(), clicked -> {
            if (clicked) {
                // Navigate to BuyFragment
                Navigation.findNavController(requireView()).navigate(R.id.action_homeFragment_to_buyFragment);
                // Reset the value of buyClicked LiveData
                viewModel.resetBuyClicked(); // Resetting the value to false
            }
        });

        // Observe sellClicked LiveData
        viewModel.getSellClicked().observe(getViewLifecycleOwner(), clicked -> {
            if (clicked) {
                // Navigate to SellFragment
                Navigation.findNavController(requireView()).navigate(R.id.action_homeFragment_to_sellFragment);
                // Reset the value of sellClicked LiveData
                viewModel.resetSellClicked(); // Resetting the value to false
            }
        });

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
