package com.example.chatting;
import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class RecyclerAdapter extends FirebaseRecyclerAdapter<model, RecyclerAdapter.ViewHolder> {

    public RecyclerAdapter(@NonNull FirebaseRecyclerOptions<model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull model product) {
        holder.bind(product);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_item_layout, parent, false);
        return new ViewHolder(view);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView productImageView;
        private final TextView productNameTextView;
        private final TextView productPriceTextView;
        private final TextView productDescriptionTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productNameTextView = itemView.findViewById(R.id.text_product_name);
            productPriceTextView = itemView.findViewById(R.id.text_price);
            productDescriptionTextView = itemView.findViewById(R.id.text_product_content);
            productImageView = itemView.findViewById(R.id.image_product);
        }

        @SuppressLint("SetTextI18n")
        public void bind(model product) {
            productNameTextView.setText(product.getName());
            productPriceTextView.setText("Rs." + product.getPrice());
            productDescriptionTextView.setText(product.getDescription());
            // Inside your ViewHolder class
            Glide.with(itemView.getContext())
                    .load(product.getImageUrl()) // Replace product.getImageUrl() with the URL of your image retrieved from Firebase Storage
                    .into(productImageView);

        }
    }
}
