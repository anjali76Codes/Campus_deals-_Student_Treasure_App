package com.example.chatting.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.chatting.databinding.FragmentHomeBinding;
import com.example.chatting.R;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        // Set up button click listeners
        binding.btnBuy.setOnClickListener(v -> navigateToBuyFragment());
        binding.btnSell.setOnClickListener(v -> navigateToSellFragment());

        return view;
    }

    private void navigateToBuyFragment() {
        // Navigate to BuyFragment
        Navigation.findNavController(requireView()).navigate(R.id.action_homeFragment_to_buyFragment);
    }

    private void navigateToSellFragment() {
        // Navigate to SellFragment
        Navigation.findNavController(requireView()).navigate(R.id.action_homeFragment_to_sellFragment);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
