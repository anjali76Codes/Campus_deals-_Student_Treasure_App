package com.example.chatting.ui.mycart;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MyCartViewModel extends ViewModel {
    // TODO: Implement the ViewModel

    public static MutableLiveData<String> mText;

    public  MyCartViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is My Cart fragment");
    }

    public MyCartViewModel(MutableLiveData<String> mText) {
        MyCartViewModel.mText = mText;
    }

    public static LiveData<String> getText() {
        return mText;
    }
}